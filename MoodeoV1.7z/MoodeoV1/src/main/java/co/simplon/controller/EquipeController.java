package co.simplon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import co.simplon.model.Equipe;
import co.simplon.service.EquipeService;

/**
 * 
 * @author Robin
 * Classe controller de l'API Rest qui 
 * permet de faire le lien avec la partie front,
 * Chaque méthode lie une URI aux méthodes du service EquipeService.
 *
 */

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/moodeo")
public class EquipeController {

	
	@Autowired
	EquipeService equipeService;
	
	// URI pour récupérer la liste des équipes "http://localhost:8080/moodeo/equipes"
	@RequestMapping(value="/equipes", method = RequestMethod.GET)
	public ResponseEntity <?> getListeEquipes(){
		
		List<Equipe> listeEquipe = null;
		
		try {
			// Appel du service
			listeEquipe = equipeService.getListeEquipes();
			
		} catch (Exception e) {
			
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(listeEquipe);
	}
	
	// URI pour récupérer la informations d'une équipe "http://localhost:8080/moodeo/equipe/{id}"
	@RequestMapping(value="/equipe/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> getEquipe(@PathVariable int id){
		
		Equipe equipe;
		
		try {
			// Appel du service
			equipe = equipeService.getEquipe(id);
			
		} catch (Exception e) {
			
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
		// Si l'équipe n'existe pas
		if (equipe == null){
			
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		return ResponseEntity.status(HttpStatus.OK).body(equipe);
	}
	
	// URI pour récupérer créer une équipe "http://localhost:8080/moodeo/equipe"
	@RequestMapping(value="/equipe", method = RequestMethod.POST)
	public ResponseEntity<?> insertEquipe(@RequestBody Equipe equipe){
		boolean verifEquipe = false;
		Equipe resultEquipe;
		
		try {
			// On vérifie que l'équipe n'est pas déjà en base
			verifEquipe = equipeService.verifEquipeExiste(equipe);
			if (verifEquipe != false){
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("L'équipe existe déjà");
			} else {
		try {
			// Si l'équipe n'existe pas, on appelle le service pour la créer
			resultEquipe = equipeService.insertEquipe(equipe);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
		
		return ResponseEntity.status(HttpStatus.CREATED).body(resultEquipe);
		
	}
			} catch (Exception e) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
	}
	}
	
	// URI pour mettre à jour une équipe "http://localhost:8080/moodeo/equipe/{id}"
	@RequestMapping(value="/equipe/{id}", method = RequestMethod.PUT)
	public ResponseEntity<?> updateEquipe(@PathVariable int id, @RequestBody Equipe equipe){
		
		Equipe result;
		
		try {
			// Appel du service
			result = equipeService.updateEquipe(id, equipe);
			
		} catch (Exception e) {
			
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
		
		return  ResponseEntity.status(HttpStatus.CREATED).body(result);
	}
	
	// URI pour récupérer la liste des équipes d'un établissement "http://localhost:8080/moodeo/equipes/etablissemement/{id}"
	@RequestMapping(value="/equipes/etablissement/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> getEquipeEtablissement(@PathVariable int id){
		List<Equipe> listeEquipe = null;
		
		try {
			// Appel du service
			listeEquipe = equipeService.getListeEquipeEtablissement(id);
			
		} catch (Exception e) {
			
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(listeEquipe);
	}
	
	}

