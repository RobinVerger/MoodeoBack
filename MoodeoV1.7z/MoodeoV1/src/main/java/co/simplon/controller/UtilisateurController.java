package co.simplon.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import co.simplon.model.Utilisateur;
import co.simplon.service.UtilisateurService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/moodeo")
public class UtilisateurController {

	@Autowired
	UtilisateurService utilisateurService;
	
	@RequestMapping(value="/utilisateurs", method = RequestMethod.GET)
	public ResponseEntity <?> getListeUtilisateurs(){
		
		List<Utilisateur> listeUtilisateur = null;
		
		try {
			listeUtilisateur = utilisateurService.getListeUtilisateurs();
			
		} catch (Exception e) {
			
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(listeUtilisateur);
	}
	
	@RequestMapping(value="/utilisateurs/etablissement/{idEtablissement}", method = RequestMethod.GET)
	public ResponseEntity <?> getListeUtilisateurParEtablissement(@PathVariable int idEtablissement){

		List<Utilisateur> listeUtilisateur = null;
		
		try {
			listeUtilisateur = utilisateurService.getListeUtilisateurParEtablissement(idEtablissement);
			
		} catch (Exception e) {
			
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(listeUtilisateur);
	}
	
	@RequestMapping(value="/utilisateur/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> getUtilisateur(@PathVariable int id){
		
		Utilisateur utilisateur;
		
		try {
			
			utilisateur = utilisateurService.getUtilisateur(id);
			
		} catch (Exception e) {
			
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
		if (utilisateur == null){
			
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		}
		return ResponseEntity.status(HttpStatus.OK).body(utilisateur);
	}
	
	@RequestMapping(value="/verifUtilisateur", method = RequestMethod.GET)
	public boolean verifUtilisateur(@RequestBody Utilisateur utilisateur){
		boolean verifUtilisateurExiste = false;

		try {
			verifUtilisateurExiste = utilisateurService.verifUtilisateurExiste(utilisateur);
		} catch (Exception e) {

			e.printStackTrace();
		}
		
		return verifUtilisateurExiste;
	}
	
	@RequestMapping(value="/utilisateur", method = RequestMethod.POST)
	public ResponseEntity<?> insertUtilisateur(@RequestBody Utilisateur utilisateur){
		boolean verifUtilisateur = false;
		Utilisateur resultUtilisateur;
			
		try {
			verifUtilisateur = utilisateurService.verifUtilisateurExiste(utilisateur);
			if (verifUtilisateur != false){
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("L'utilisateur existe déjà");
			} else {
		try {
			resultUtilisateur = utilisateurService.insertUtilisateur(utilisateur);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
		
		return ResponseEntity.status(HttpStatus.CREATED).body(resultUtilisateur);
		
	}
			} catch (Exception e) {
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
			}
	}
	
	@RequestMapping(value="/utilisateur/{id}", method = RequestMethod.PUT)
	public ResponseEntity<?> updateUtilisateur(@PathVariable int id, @RequestBody Utilisateur utilisateur){
		
		Utilisateur result;
//		String nom = utilisateur.getNom();
//		String prenom = utilisateur.getPrenom();
//		String role = utilisateur.getRole();
//		int idEquipe = utilisateur.getIdEquipe();
		
		//if((nom != null && !nom.isEmpty()) && (prenom != null && !prenom.isEmpty())  && (role != null && role.isEmpty()) && (idEquipe != 0)) {
			
		try {
			result = utilisateurService.updateUtilisateur(id, utilisateur);
			
		} catch (Exception e) {
			
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
		
		return  ResponseEntity.status(HttpStatus.CREATED).body(result);
	
//	} else {
//		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Vérifiez que les champs soient bien remplis");
//	}
}
}
