package co.simplon.dao;

import co.simplon.model.Humeur;

/**
 * 
 * @author Robin
 *	Interface qui définit les méthodes utilisables dans la classe jdbcHumeurDAO
 */
public interface HumeurDAO {

	public Humeur getHumeur(int idUtilisateur) throws Exception;
	
	public Humeur insertHumeur(Humeur humeur) throws Exception;
	
	public Humeur getHumeurEquipe(int idEquipe) throws Exception;
	
	public Humeur getHumeurEtablissement(int idEtablissement) throws Exception;
	
	public Humeur getHumeurEquipeMois(int idEquipe, int mois) throws Exception;
	
	public Humeur getHumeurEtablissementMois(int idEtablissement, int mois) throws Exception;
	
	public Humeur getHumeurEquipeUtilisateur(int idUtilisateur) throws Exception;
	
	public Humeur getHumeurEtablissementUtilisateur(int idUtilisateur) throws Exception;
	
	public Humeur getHumeurEquipeParDate(int idEquipe, String date) throws Exception;
	
	public Humeur getHumeurEtablissementParDate(int idEtablissement, String date) throws Exception;
	
	public boolean verifVoteUtilisateur(Humeur humeur) throws Exception;
}
