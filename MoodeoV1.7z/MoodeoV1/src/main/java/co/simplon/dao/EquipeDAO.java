package co.simplon.dao;

import java.util.List;

import co.simplon.model.Equipe;

/**
 * @author Robin
 *	Interface qui définit les méthodes utilisables dans la classe jdbcEquipeDAO
 */
public interface EquipeDAO {

	public List<Equipe> getListeEquipes() throws Exception;
	
	public Equipe getEquipe(int id) throws Exception;
	
	public Equipe insertEquipe(Equipe equipe) throws Exception;
	
	public Equipe updateEquipe(Equipe equipe) throws Exception;
	
	public boolean verifEquipeExiste(Equipe equipe) throws Exception;
	
	public List<Equipe> getListeEquipeEtablissement(int idEtablissement) throws Exception;
	
}
