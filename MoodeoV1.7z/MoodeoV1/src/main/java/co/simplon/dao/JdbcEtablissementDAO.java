package co.simplon.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import co.simplon.model.Etablissement;

@Repository
public class JdbcEtablissementDAO implements EtablissementDAO {
	private DataSource dataSource;
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	public JdbcEtablissementDAO(JdbcTemplate jdbcTemplate) {
		this.dataSource = jdbcTemplate.getDataSource();
	}
	
	/**
	 * Cette méthode récupère tous les établissements de la base de données et les ajoute à une liste d'établissements
	 * puis retourne cette liste
	 * @return listEtablissement
	 * @throws Exception
	 */
	@Override
	public List<Etablissement> getListeEtablissements() throws Exception{

		Etablissement etablissement;
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		ArrayList<Etablissement> listEtablissements = new ArrayList<Etablissement>();
		
		try {
			// Requête SQL permettant de récupérer une liste de tous les établissements
			sql = "SELECT * FROM etablissement";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			
			// Exécute la requete
			rs = pstmt.executeQuery();
						
			// Log info
			logSQL(pstmt);

			// à chaque fois que l'on trouve un établissement, on le rajoute à la liste
			while (rs.next()) {
				etablissement = getEtablissementFromResultSet(rs);
				listEtablissements.add(etablissement);
			}
			
		} catch (Exception e) {
		e.printStackTrace();
		log.error("SQL Error !:" + pstmt.toString(), e);
		throw e;
		
	} finally {
		pstmt.close();
	}
		
		return listEtablissements;
	}
	
	/**
	 * Cette méthode récupère les informations d'un établissement en base de données à partir de son id
	 * @param id
	 * @return etablissement
	 * @throws Exception
	 */
	@Override
	public Etablissement getEtablissement(int id) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		Etablissement etablissement = null;
		
		try {
			//Prépare la requête SQL 
			sql = "SELECT * FROM etablissement WHERE id_etablissement = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(1, id);
			
			// Log info
			logSQL(pstmt);

			// Exécute la requête
			rs = pstmt.executeQuery();
						
			// gère le résultat de la rêquete
			if (rs.next())
				etablissement = getEtablissementFromResultSet(rs);
		
		} catch (SQLException e){
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
		
		} finally {
			pstmt.close();
		}
		
		return etablissement;
		}
	
	/**
	 * Cette fonction permet de récupérer l'établissement d'un utilisateur en prenant 
	 * en paramètre son id
	 */
	@Override
	public Etablissement getEtablissementUtilisateur(int idUtilisateur) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		Etablissement etablissement = null;
		
		try {
			sql = "SELECT * FROM etablissement et INNER JOIN equipe e ON et.id_etablissement = e.etablissement_id"
					+ " INNER JOIN utilisateur u ON e.id_equipe = u.equipe_id"
					+ " WHERE u.id_utilisateur = ?;";
			
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(1, idUtilisateur);
		// Log info
		logSQL(pstmt);

		// Exécute la requête
		rs = pstmt.executeQuery();
					
		// gère le résultat de la rêquete
		if (rs.next())
			etablissement = getEtablissementFromResultSet(rs);
	
	} catch (SQLException e){
		e.printStackTrace();
		log.error("SQL Error !:" + pstmt.toString(), e);
		throw e;
	
	} finally {
		pstmt.close();
	}
	
	return etablissement;
	}
	
	/**
	 * Cette méthode permet d'ajouter un établissement et ses informations dans la base de données
	 * @param etablissement
	 * @return etablissement
	 * @throws Exception
	 */
	@Override
	public Etablissement insertEtablissement(Etablissement etablissement) throws Exception {
		PreparedStatement pstmt = null;
		Etablissement result = null;
		String sql;
		int i = 0;
		
		try {
			//Prépare la requête SQL
			sql = "INSERT INTO etablissement (nom, adresse, code_postal, region) VALUES (?, ?, ?, ?)";
			pstmt = dataSource.getConnection().prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setString(++i, etablissement.getNom());
			pstmt.setString(++i, etablissement.getAdresse());
			pstmt.setString(++i, etablissement.getCodePostal());
			pstmt.setString(++i, etablissement.getRegion());
			
			// Log info
			logSQL(pstmt);
						
			// Execute la requête
			pstmt.executeUpdate();
		
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
			
		} finally {
			pstmt.close();
		}
		
		return result;
		}
	
	/**
	 * Cette méthode permet de mettre à jour les informations d'un établissement
	 * @param etablissement
	 * @return etablissement
	 * @throws Exception
	 */
	@Override
	public Etablissement updateEtablissement(Etablissement etablissement) throws Exception {
		Etablissement result = null;
		PreparedStatement pstmt = null;
		String sql = null;
		int i = 0;

		try {
			//Prépare la requête
			sql ="UPDATE etablissement SET nom = ?, adresse = ?, code_postal = ?, region = ? WHERE id_etablissement = ?";
			
			pstmt = dataSource.getConnection().prepareStatement(sql);
            pstmt.setString(++i, etablissement.getNom());
            pstmt.setString(++i, etablissement.getAdresse());
            pstmt.setString(++i, etablissement.getCodePostal());
            pstmt.setString(++i, etablissement.getRegion());
            pstmt.setInt(++i, etablissement.getId());
            
         // Log info
            logSQL(pstmt);
         			
         // Exécute la requête
         	int resultCount = pstmt.executeUpdate();
         	if(resultCount != 1)
         				throw new Exception("Etablissement non trouvé !");
         			
         	result = etablissement;

         		} catch (SQLException e) {
         			e.printStackTrace();
         			log.error("SQL Error !:" + pstmt.toString(), e);
         			throw e;
         			
         		} finally {
         			pstmt.close();
         		}

         		return result;
	}
	
	/**
	 * Cette méthode permet de vérifier si un établissement existe déjà en base de données
	 * Cette méthode sera principalement utilisée lors d'ajout de nouveaux établissement en base 
	 * @param etablissement
	 * @return boolean
	 * @throws Exception
	 */
	@Override
	public boolean verifEtablissementExiste(Etablissement etablissement) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs;
		int i = 0;
		boolean resultEtablissement = false;
		String sql = null;
		
		try {
			//Prépare la requête
			sql = "SELECT * FROM etablissement WHERE nom = ? AND adresse = ? AND code_postal = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
            
            pstmt.setString(++i, etablissement.getNom());
            pstmt.setString(++i, etablissement.getAdresse());
            pstmt.setString(++i, etablissement.getCodePostal());
            
         // Log info
         	logSQL(pstmt);

         // Run requete
         	rs = pstmt.executeQuery();
         			
         // si al requête a un résultat, on renvoie true
         	if (rs.next())
         		resultEtablissement = true;
         	
         	} catch (SQLException e) {
         			e.printStackTrace();
         			log.error("SQL Error !:" + pstmt.toString(), e);
         			throw e;
         	
         	} finally {
         			pstmt.close();
         		}
		
         	return resultEtablissement;
		}
	
	
	
	
	/**
	 * Construit un établissement à partir du résultat de ResultSet
	 * @param rs
	 * @return etablissement
	 * @throws SQLException
	 */
	private Etablissement getEtablissementFromResultSet(ResultSet rs) throws SQLException {
		Etablissement etablissement = new Etablissement();
		etablissement.setId(rs.getInt("id_etablissement"));
		etablissement.setNom(rs.getString("nom"));
		etablissement.setAdresse(rs.getString("adresse"));
		etablissement.setCodePostal(rs.getString("code_postal"));
		etablissement.setRegion(rs.getString("region"));
		
		return etablissement;		
	}
	
	private void logSQL(PreparedStatement pstmt) {
		String sql;
		
		if (pstmt == null)
			return;
		
		sql = pstmt.toString().substring(pstmt.toString().indexOf(":") + 2);
		log.debug(sql);
	}


}
