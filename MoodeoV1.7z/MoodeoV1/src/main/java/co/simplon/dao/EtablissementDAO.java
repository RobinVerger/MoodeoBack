package co.simplon.dao;

import java.util.List;

import co.simplon.model.Etablissement;

/**
 * 
 * @author Robin
 *	Interface qui définit les méthodes utilisables dans la classe jdbcEtablissementDAO
 */
public interface EtablissementDAO {

	public List<Etablissement> getListeEtablissements() throws Exception;
	
	public Etablissement getEtablissement(int id) throws Exception;
	
	public Etablissement insertEtablissement(Etablissement etablissement) throws Exception;
	
	public Etablissement updateEtablissement(Etablissement etablissement) throws Exception;
	
	public Etablissement getEtablissementUtilisateur(int idUtilisateur) throws Exception;
	
	public boolean verifEtablissementExiste(Etablissement etablissement) throws Exception;
}
