package co.simplon.dao;

import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Year;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import co.simplon.model.Humeur;

/**
 * 
 * @author Robin
 * Cette classe définit les méthodes d'intéraction avec la base de
 * données
 */
@Repository
public class JdbcHumeurDAO implements HumeurDAO {

	private DataSource dataSource;
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	public JdbcHumeurDAO(JdbcTemplate jdbcTemplate) {
		this.dataSource = jdbcTemplate.getDataSource();
	}

	/**
	 * cette méthode permet de récupérer l'humeur d'un utilisateur à partir de son id
	 */
	@Override
	public Humeur getHumeur(int idUtilisateur) throws Exception {
		Date date = new Date();
		String dateJour = new SimpleDateFormat("yyyy-MM-dd").format(date);
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		Humeur humeur = null;
		int i = 0;
		
		try {
			//Prépare la requête SQL 
			sql = "SELECT * FROM humeur WHERE utilisateur_id = ? AND date_creation = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(++i, idUtilisateur);
			pstmt.setString(++i, dateJour);
			
			// Log info
			logSQL(pstmt);

			// Exécute la requête
			rs = pstmt.executeQuery();
						
			// gère le résultat de la rêquete
			if (rs.next())
				humeur = getHumeurFromResultSet(rs);

		} catch (SQLException e){
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
		
		} finally {
			pstmt.close();
		}
		
		return humeur;
	}

	/**
	 * Cette méthode permet d'insérer en base une humeur.
	 * Elle prend en paramètre l'objet humeur que l'on souhaite ajouter
	 */
	@Override
	public Humeur insertHumeur(Humeur humeur) throws Exception {
		Date date = new Date();
		String dateJour = new SimpleDateFormat("yyyy-MM-dd").format(date);
		PreparedStatement pstmt = null;
		Humeur result = null;
		String sql;
		int i = 0;
		
		try {
			//Prépare la requête SQL
			sql = "INSERT INTO humeur (valeur, date_creation, utilisateur_id) VALUES (?, ?, ?)";
			pstmt = dataSource.getConnection().prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setFloat(++i, humeur.getValeur());
			pstmt.setString(++i, dateJour);
			pstmt.setInt(++i, humeur.getIdUtilisateur());
			
			// Log info
			logSQL(pstmt);
						
			// Execute la requête
			pstmt.executeUpdate();
		
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
			
		} finally {
			pstmt.close();
		}
		
		return result;
	}

	/**
	 * Cette méthode permet de récupérer l'humeur moyenne d'une équipe à partir de son id
	 */
	@Override
	public Humeur getHumeurEquipe(int idEquipe) throws Exception {
		Date date = new Date();
		String dateJour = new SimpleDateFormat("yyyy-MM-dd").format(date);
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		int i = 0;
		Humeur humeur = null;
		
		try {
			//Prépare la requête SQL 
			sql = "SELECT round(avg(h.valeur), 1) AS valeur FROM humeur h"
					+ " INNER JOIN utilisateur u ON u.id_utilisateur = h.utilisateur_id"
					+ " INNER JOIN equipe e ON e.id_equipe = u.equipe_id"
					+ " WHERE e.id_equipe = ? AND date_creation = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(++i, idEquipe);
			pstmt.setString(++i, dateJour);
			
			// Log info
			logSQL(pstmt);

			// Exécute la requête
			rs = pstmt.executeQuery();
						
			// gère le résultat de la rêquete
			if (rs.next())
				humeur = getHumeurMoyenneFromResultSet(rs);
		
		} catch (SQLException e){
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
		
		} finally {
			pstmt.close();
		}
		
		return humeur;
	}

	/**
	 * Cette méthode permet de récupérer l'humeur moyenne d'un établissement à partir de son id 
	 * passé en paramètre
	 */
	@Override
	public Humeur getHumeurEtablissement(int idEtablissement) throws Exception {
		Date date = new Date();
		String dateJour = new SimpleDateFormat("yyyy-MM-dd").format(date);
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		int i = 0;
		Humeur humeur = null;
		
		try {
			//Prépare la requête SQL 
			sql = "SELECT round(avg(h.valeur), 1) AS valeur FROM humeur h"
					+ " INNER JOIN utilisateur u ON u.id_utilisateur = h.utilisateur_id"
					+ " INNER JOIN equipe e ON e.id_equipe = u.equipe_id"
					+ " INNER JOIN etablissement et ON et.id_etablissement = e.etablissement_id"
					+ " WHERE et.id_etablissement = ? AND date_creation = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(++i, idEtablissement);
			pstmt.setString(++i, dateJour);
			
			// Log info
			logSQL(pstmt);

			// Exécute la requête
			rs = pstmt.executeQuery();
						
			// gère le résultat de la rêquete
			if (rs.next())
				humeur = getHumeurFromResultSet(rs);
		
		} catch (SQLException e){
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
		
		} finally {
			pstmt.close();
		}
		
		return humeur;
	}

	/**
	 * Cette méthode permet de vérifier si un utilisateur a déjà donner son humeur à la date du jour.
	 * et renvoie true si c'est le cas.
	 * 
	 */
	@Override
	public boolean verifVoteUtilisateur(Humeur humeur) throws Exception {
		Date date = new Date();
		String dateJour = new SimpleDateFormat("yyyy-MM-dd").format(date);
		PreparedStatement pstmt = null;
		ResultSet rs;
		int i = 0;
		boolean resultatHumeur = false;
		String sql = null;
		
		try {
			//Prépare la requête
			sql = "SELECT * FROM humeur WHERE utilisateur_id = ? AND date_creation = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
            
            pstmt.setInt(++i, humeur.getIdUtilisateur());
            pstmt.setString(++i, dateJour);
            
         // Log info
         	logSQL(pstmt);

         // Run requete
         	rs = pstmt.executeQuery();
         			
         // Si on trouve un résultat, on renvoie true
         	if (rs.next())
         		resultatHumeur= true;
         	
         	} catch (SQLException e) {
         			e.printStackTrace();
         			log.error("SQL Error !:" + pstmt.toString(), e);
         			throw e;
         	
         	} finally {
         			pstmt.close();
         		}
		
         	return resultatHumeur;
	}
	
	/**
	 * (Cette méthode n'est pas utilisée pour l'instant, elle a été développée en prévision pour
	 * les fonctionnalités des prochaines versions)
	 * Cette méthode permet de récupérer l'humeur moyenne d'une équipe sur un mois précis de l'année en cours.
	 * Elle prend en paramètre l'id de l'équipe dont on souhaite connaitre l'humeur
	 * et le mois durant lequel on souhaite consulter l'humeur
	 */
	@Override
	public Humeur getHumeurEquipeMois(int idEquipe, int mois) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		int i = 0;
		Humeur humeur = null;
		int annee = Year.now().getValue();
		
		try {
			//Prépare la requête SQL 
			sql = "SELECT round(avg(h.valeur), 1) AS valeur FROM humeur h"
					+ " INNER JOIN utilisateur u ON u.id_utilisateur = h.utilisateur_id"
					+ " INNER JOIN equipe e ON e.id_equipe = u.equipe_id"
					+ " WHERE e.id_equipe = ? AND month(date_creation) = ? AND year(date_creation) = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(++i, idEquipe);
			pstmt.setInt(++i, mois);
			pstmt.setInt(++i, annee);
			
			// Log info
			logSQL(pstmt);

			// Exécute la requête
			rs = pstmt.executeQuery();
						
			// gère le résultat de la rêquete
			if (rs.next())
				humeur = getHumeurMoyenneFromResultSet(rs);
		
		} catch (SQLException e){
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
		
		} finally {
			pstmt.close();
		}
		
		return humeur;
	}

	/**
	 * (Cette méthode n'est pas utilisée pour l'instant, elle a été développée en prévision pour
	 * les fonctionnalités des prochaines versions)
	 * Cette méthode permet de récupérer l'humeur moyenne d'un établissement sur un mois précis de l'année en cours.
	 * Elle prend en paramètre l'id de l'établissement dont on souhaite connaitre l'humeur
	 * et le mois durant lequel on souhaite consulter l'humeur
	 */
	@Override
	public Humeur getHumeurEtablissementMois(int idEtablissement, int mois) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		int i = 0;
		Humeur humeur = null;
		int annee = Year.now().getValue();
		
		try {
			//Prépare la requête SQL 
			sql = "SELECT round(avg(h.valeur), 1) AS valeur FROM humeur h"
					+ " INNER JOIN utilisateur u ON u.id_utilisateur = h.utilisateur_id"
					+ " INNER JOIN equipe e ON e.id_equipe = u.equipe_id"
					+ " INNER JOIN etablissement et ON et.id_etablissement = e.etablissement_id"
					+ " WHERE et.id_etablissement = ? AND month(date_creation) = ? AND year(date_creation) = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(++i, idEtablissement);
			pstmt.setInt(++i, mois);
			pstmt.setInt(++i, annee);
			
			// Log info
			logSQL(pstmt);

			// Exécute la requête
			rs = pstmt.executeQuery();
						
			// gère le résultat de la rêquete
			if (rs.next())
				humeur = getHumeurMoyenneFromResultSet(rs);
		
		} catch (SQLException e){
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
		
		} finally {
			pstmt.close();
		}
		
		return humeur;
	}

	/**
	 * Cette méthode permet de récupérer l'humeur moyenne de l'équipe de l'utilisateur dont l'id 
	 * est passé en paramètre
	 */
	@Override
	public Humeur getHumeurEquipeUtilisateur(int idUtilisateur) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		int i = 0;
		Humeur humeur = null;
		Date date = new Date();
		String dateJour = new SimpleDateFormat("yyyy-MM-dd").format(date);
		
		try {
			sql = "SELECT round(avg(valeur), 1) AS valeur FROM humeur h"
					+ " INNER JOIN utilisateur u ON u.id_utilisateur = h.utilisateur_id"
					+ " WHERE u.equipe_id = ? AND h.date_creation = ?;";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(++i, idUtilisateur);
			pstmt.setString(++i, dateJour);
			
			// Log info
						logSQL(pstmt);

						// Exécute la requête
						rs = pstmt.executeQuery();
									
						// gère le résultat de la rêquete
						if (rs.next())
							humeur = getHumeurMoyenneFromResultSet(rs);
			
			
		} catch (SQLException e){
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
		
		} finally {
			pstmt.close();
		}
		return humeur;
	}
	
	/**
	 * Cette méthode permet de récupérer l'humeur moyenne de l'établissement de l'utilisateur
	 * dont l'id est passé en paramètre
	 */
	@Override
	public Humeur getHumeurEtablissementUtilisateur(int idUtilisateur) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		int i = 0;
		Humeur humeur = null;
		Date date = new Date();
		String dateJour = new SimpleDateFormat("yyyy-MM-dd").format(date);
		
		try {
			sql = "SELECT round(avg(valeur), 1) AS valeur FROM humeur h"
					+ " INNER JOIN utilisateur u ON u.id_utilisateur = h.utilisateur_id"
					+ " INNER JOIN equipe e ON e.id_equipe = u.equipe_id"
					+ " INNER JOIN etablissement et ON et.id_etablissement = e.etablissement_id"
					+ " WHERE et.id_etablissement = ? AND h.date_creation = ?;";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(++i, idUtilisateur);
			pstmt.setString(++i, dateJour);
			
			// Log info
						logSQL(pstmt);

						// Exécute la requête
						rs = pstmt.executeQuery();
									
						// gère le résultat de la rêquete
						if (rs.next())
							humeur = getHumeurMoyenneFromResultSet(rs);
			
			
		} catch (SQLException e){
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
		
		} finally {
			pstmt.close();
		}
		return humeur;
	}

	/**
	 * Cette méthode permet de récupérer l'humeur moyenne d'une équipe à une date choisie
	 * Elle prend en paramètre l'id de l'équipe dont on souhaite connaitre l'humeur
	 * et la date à laquelle on souhaite connaitre l'humeur
	 */
	@Override
	public Humeur getHumeurEquipeParDate(int idEquipe, String date) throws Exception{
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		int i = 0;
		Humeur humeur = null;
		
		try {
			sql = "SELECT round(avg(valeur), 1) AS valeur FROM humeur h"
					+ " INNER JOIN utilisateur u ON u.id_utilisateur = h.utilisateur_id"
					+ " WHERE u.equipe_id = ? AND h.date_creation = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(++i, idEquipe);
			pstmt.setString(++i, date); 
			
			// Log info
			logSQL(pstmt);

			// Exécute la requête
			rs = pstmt.executeQuery();
						
			// gère le résultat de la rêquete
			if (rs.next())
				humeur = getHumeurMoyenneFromResultSet(rs);
			
	} catch (SQLException e){
		e.printStackTrace();
		log.error("SQL Error !:" + pstmt.toString(), e);
		throw e;
	
	} finally {
		pstmt.close();
	}
	return humeur;
}

	/**
	 * Cette méthode permet de récupérer l'humeur moyenne d'un établissement à une date choisie
	 * Elle prend en paramètre l'id de l'établissement dont on souhaite connaitre l'humeur
	 * et la date à laquelle on souhaite connaitre l'humeur
	 */
	@Override
	public Humeur getHumeurEtablissementParDate(int idEtablissement, String date) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		int i = 0;
		Humeur humeur = null;
		
		try {
			sql = "SELECT round(avg(valeur), 1) AS valeur FROM humeur h"
					+ " INNER JOIN utilisateur u ON u.id_utilisateur = h.utilisateur_id"
					+ " INNER JOIN equipe e ON e.id_equipe = u.equipe_id"
					+ " WHERE e.etablissement_id = ? AND h.date_creation = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(++i, idEtablissement);
			pstmt.setString(++i, date); 
			
			// Log info
			logSQL(pstmt);

			// Exécute la requête
			rs = pstmt.executeQuery();
						
			// gère le résultat de la rêquete
			if (rs.next())
				humeur = getHumeurMoyenneFromResultSet(rs);
			
	} catch (SQLException e){
		e.printStackTrace();
		log.error("SQL Error !:" + pstmt.toString(), e);
		throw e;
	
	} finally {
		pstmt.close();
	}
	return humeur;
	}

	private Humeur getHumeurFromResultSet(ResultSet rs) throws SQLException {
		Humeur humeur = new Humeur();
		humeur.setValeur(rs.getFloat("valeur"));
		humeur.setDateCreation(rs.getDate("date_creation"));
		humeur.setIdUtilisateur(rs.getInt("utilisateur_id"));
		
		return humeur;		
	}
	
	private Humeur getHumeurMoyenneFromResultSet(ResultSet rs) throws SQLException {
		Humeur humeur = new Humeur();
		
		humeur.setValeur(rs.getFloat("valeur"));
		
		return humeur;
	}
	
	private void logSQL(PreparedStatement pstmt) {
		String sql;
		
		if (pstmt == null)
			return;
		
		sql = pstmt.toString().substring(pstmt.toString().indexOf(":") + 2);
		log.debug(sql);
	}


}
