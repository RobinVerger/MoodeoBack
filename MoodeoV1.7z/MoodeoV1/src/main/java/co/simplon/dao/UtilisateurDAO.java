package co.simplon.dao;

import java.util.List;

import co.simplon.model.Utilisateur;

/**
 * 
 * @author Robin
 *	Interface qui définit les méthodes utilisables dans la classe jdbcUtilisateurDAO
 */
public interface UtilisateurDAO {

	public List<Utilisateur> getListeUtilisateurs() throws Exception;
	
	public List<Utilisateur> getUtilisateurParEtablissement(int idEtablissement) throws Exception;
	
	public Utilisateur getUtilisateur(int id) throws Exception;
	
	public Utilisateur insertUtilisateur(Utilisateur utilisateur) throws Exception;
	
	public Utilisateur updateUtilisateur(Utilisateur utilisateur) throws Exception;
	
	public boolean verifUtilisateurExiste(Utilisateur utilisateur) throws Exception;
	
}
