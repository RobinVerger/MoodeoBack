package co.simplon.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import co.simplon.model.Equipe;

/**
 * 
 * @author Robin 
 * Cette classe définit les méthodes d'intéraction avec la base de
 *         données
 *
 */
@Repository
public class JdbcEquipe implements EquipeDAO {

	private DataSource dataSource;
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	public JdbcEquipe(JdbcTemplate jdbcTemplate) {
		this.dataSource = jdbcTemplate.getDataSource();
	}
	
	/**
	 * Cette fonction permet de récupérer toutes les équipes présentes en base de données
	 */
	@Override
	public List<Equipe> getListeEquipes() throws Exception {
		Equipe equipe;
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		ArrayList<Equipe> listeEquipes = new ArrayList<Equipe>();
		
		try {
			// Requête SQL
			sql = "SELECT * FROM equipe";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			
			// Exécute la requete
			rs = pstmt.executeQuery();
						
			// Log info
			logSQL(pstmt);

			// tant que l'on trouve une équipe, on l'ajoute à la liste
			while (rs.next()) {
				equipe = getEquipeFromResultSet(rs);
				listeEquipes.add(equipe);
			}
			
		} catch (Exception e) {
		e.printStackTrace();
		log.error("SQL Error !:" + pstmt.toString(), e);
		throw e;
		
	} finally {
		pstmt.close();
	}
		
		return listeEquipes;
	}

	/**
	 * Cette méthode permet de récupérer la liste des équipe d'un établissement en prenant en
	 * paramètre son id.
	 */
	@Override
	public List<Equipe> getListeEquipeEtablissement(int idEtablissement) throws Exception {
		
		Equipe equipe;
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		ArrayList<Equipe> listeEquipes = new ArrayList<Equipe>();
		
		try {
			// Requête SQL permettant de récupérer une liste de tous les établissements
			sql = "SELECT * FROM equipe WHERE etablissement_id = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(1, idEtablissement);
			
			// Exécute la requete
			rs = pstmt.executeQuery();
						
			// Log info
			logSQL(pstmt);

			// gère le resultat de la requete
			while (rs.next()) {
				equipe = getEquipeFromResultSet(rs);
				listeEquipes.add(equipe);
			}
			
		} catch (Exception e) {
		e.printStackTrace();
		log.error("SQL Error !:" + pstmt.toString(), e);
		throw e;
		
	} finally {
		pstmt.close();
	}
		
		return listeEquipes;
	}
	
	/**
	 * Cette fonction permet de récupérer les informations d'une équipe grâce 
	 * à son id passé en paramètre
	 */
	@Override
	public Equipe getEquipe(int id) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		Equipe equipe = null;
		
		try {
			//Prépare la requête SQL 
			sql = "SELECT * FROM equipe WHERE id_equipe = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(1, id);
			
			// Log info
			logSQL(pstmt);

			// Exécute la requête
			rs = pstmt.executeQuery();
						
			// gère le résultat de la rêquete
			if (rs.next())
				equipe = getEquipeFromResultSet(rs);
		
		} catch (SQLException e){
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
		
		} finally {
			pstmt.close();
		}
		
		return equipe;
	}

	/**
	 * Cette méthode permet d'insérer une nouvelle équipe en base de données
	 * Elle prend en paramètre l'objet équipe que l'on souhaite insérer
	 */
	@Override
	public Equipe insertEquipe(Equipe equipe) throws Exception {
		PreparedStatement pstmt = null;
		Equipe result = null;
		String sql;
		int i = 0;
		
		try {
			//Prépare la requête SQL
			sql = "INSERT INTO equipe (etablissement_id, libEquipe) VALUES (?, ?)";
			pstmt = dataSource.getConnection().prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setInt(++i, equipe.getIdEtablissement());
			pstmt.setString(++i, equipe.getLibEquipe());
			
			// Log info
			logSQL(pstmt);
						
			// Execute la requête
			pstmt.executeUpdate();
		
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
			
		} finally {
			pstmt.close();
		}
		
		return result;
	}

	/**
	 * Cette méthode permet de mettre à jour les informations d'une équipe
	 * Elle prend en paramètre l'objet equipe que l'on souhaite mettre à jour
	 */
	@Override
	public Equipe updateEquipe(Equipe equipe) throws Exception {
		Equipe result = null;
		PreparedStatement pstmt = null;
		String sql = null;
		int i = 0;

		try {
			//Prépare la requête
			sql ="UPDATE equipe SET etablissement_id = ?, libEquipe = ? WHERE id_equipe = ?";
			
			pstmt = dataSource.getConnection().prepareStatement(sql);
            pstmt.setInt(++i, equipe.getIdEtablissement());
            pstmt.setString(++i, equipe.getLibEquipe());
            pstmt.setInt(++i, equipe.getId());
            
         // Log info
            logSQL(pstmt);
         			
         // Exécute la requête
         	int resultCount = pstmt.executeUpdate();
         	if(resultCount != 1)
         				throw new Exception("Equipe non trouvée !");
         			
         	result = equipe;

         		} catch (SQLException e) {
         			e.printStackTrace();
         			log.error("SQL Error !:" + pstmt.toString(), e);
         			throw e;
         			
         		} finally {
         			pstmt.close();
         		}

         		return result;
	}

	/**
	 * Cette méthode permet de vérifier si une équipe existe déjà en base de données
	 * Cette méthode sera principalement utilisée lors d'ajout de nouvelles équipes en base 
	 * @param etablissement
	 * @return boolean
	 * @throws Exception
	 */
	public boolean verifEquipeExiste(Equipe equipe) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs;
		int i = 0;
		boolean resultEquipe = false;
		String sql = null;
		
		try {
			//Prépare la requête
			sql = "SELECT * FROM equipe WHERE etablissement_id = ? AND libEquipe = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
            
            pstmt.setInt(++i, equipe.getIdEtablissement());
            pstmt.setString(++i, equipe.getLibEquipe());
            
         // Log info
         	logSQL(pstmt);

         // Run requete
         	rs = pstmt.executeQuery();
         			
         // si la requête a un résultat, on renvoie true
         	if (rs.next())
         		resultEquipe= true;
         	
         	} catch (SQLException e) {
         			e.printStackTrace();
         			log.error("SQL Error !:" + pstmt.toString(), e);
         			throw e;
         	
         	} finally {
         			pstmt.close();
         		}
		
         	return resultEquipe;
		}
	
	
	/**
	 * Construit un établissement à partir du résultat de ResultSet
	 * @param rs
	 * @return etablissement
	 * @throws SQLException
	 */
	private Equipe getEquipeFromResultSet(ResultSet rs) throws SQLException {
		Equipe equipe = new Equipe();
		equipe.setId(rs.getInt("id_equipe"));
		equipe.setIdEtablissement(rs.getInt("etablissement_id"));
		equipe.setLibEquipe(rs.getString("libEquipe"));;
		
		return equipe;		
	}
	
	private void logSQL(PreparedStatement pstmt) {
		String sql;
		
		if (pstmt == null)
			return;
		
		sql = pstmt.toString().substring(pstmt.toString().indexOf(":") + 2);
		log.debug(sql);
	}


}
