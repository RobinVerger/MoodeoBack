package co.simplon.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import co.simplon.model.Utilisateur;

/**
 * 
 * @author Robin Cette classe définit les méthodes d'intéraction avec la base de
 *         données
 *
 */
@Repository
public class JdbcUtilisateurDAO implements UtilisateurDAO {

	private DataSource dataSource;
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	public JdbcUtilisateurDAO(JdbcTemplate jdbcTemplate) {
		this.dataSource = jdbcTemplate.getDataSource();
	}
	
	/**
	 * Cette fonction permet de récupérer la liste de tous les utilisateurs de l'application
	 * de la base de données
	 */
	@Override
	public List<Utilisateur> getListeUtilisateurs() throws Exception {
		Utilisateur utilisateur;
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		ArrayList<Utilisateur> listeUtilisateurs = new ArrayList<Utilisateur>();
		
		try {
			// Requête SQL permettant de récupérer une liste de tous les établissements
			sql = "SELECT * FROM utilisateur";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			
			// Exécute la requete
			rs = pstmt.executeQuery();
						
			// Log info
			logSQL(pstmt);

			// gère le resultat de la requete
			while (rs.next()) {
				utilisateur = getUtilisateurFromResultSet(rs);
				listeUtilisateurs.add(utilisateur);
			}
			
		} catch (Exception e) {
		e.printStackTrace();
		log.error("SQL Error !:" + pstmt.toString(), e);
		throw e;
		
	} finally {
		pstmt.close();
	}
		
		return listeUtilisateurs;
	}
	
	/**
	 * Cette fonction permet de récupérer la liste des utilisateurs d'un établissement dont 
	 * l'id est passé en paramètre
	 */
	@Override
	public List<Utilisateur> getUtilisateurParEtablissement(int idEtablissement) throws Exception {
		Utilisateur utilisateur;
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		ArrayList<Utilisateur> listeUtilisateurs = new ArrayList<Utilisateur>();
		
		try {
			// Requête SQL permettant de récupérer une liste de tous les établissements
			sql = "SELECT * FROM utilisateur u INNER JOIN equipe e "
					+ "ON e.id_equipe = u.equipe_id "
					+ "INNER JOIN etablissement et "
					+ "ON e.etablissement_id = et.id_etablissement "
					+ "WHERE et.id_etablissement = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(1, idEtablissement);
			
			// Exécute la requete
			rs = pstmt.executeQuery();
						
			// Log info
			logSQL(pstmt);

			// à chaque fois que l'on trouve un utilisateur, on l'ajoute à la liste
			while (rs.next()) {
				utilisateur = getUtilisateurFromResultSet(rs);
				listeUtilisateurs.add(utilisateur);
			}
			
		} catch (Exception e) {
		e.printStackTrace();
		log.error("SQL Error !:" + pstmt.toString(), e);
		throw e;
		
	} finally {
		pstmt.close();
	}
		
		return listeUtilisateurs;
	}

	/**
	 * Cette méthode permet de récupérer les informations d'un utilisateur en passant en paramètre 
	 * son id
	 */
	@Override
	public Utilisateur getUtilisateur(int id) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs;
		String sql;
		Utilisateur utilisateur = null;
		
		try {
			//Prépare la requête SQL 
			sql = "SELECT * FROM utilisateur WHERE id_utilisateur = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setInt(1, id);
			
			// Log info
			logSQL(pstmt);

			// Exécute la requête
			rs = pstmt.executeQuery();
						
			// gère le résultat de la rêquete
			if (rs.next())
				utilisateur = getUtilisateurFromResultSet(rs);
		
		} catch (SQLException e){
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
		
		} finally {
			pstmt.close();
		}
		
		return utilisateur;
	}
	
	/**
	 * Cette méthode permet d'insérer en base de données un nouvel utilisateur.
	 * Elle prend en paramètre un objet Utilisateur
	 */
	@Override
	public Utilisateur insertUtilisateur(Utilisateur utilisateur) throws Exception {
		PreparedStatement pstmt = null;
		Utilisateur result = null;
		String sql;
		int i = 0;
		
		try {
			//Prépare la requête SQL
			sql = "INSERT INTO utilisateur (nom, prenom, role, equipe_id, date_naissance) VALUES (?, ?, ?, ?, ?)";
			pstmt = dataSource.getConnection().prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
			pstmt.setString(++i, utilisateur.getNom());
			pstmt.setString(++i, utilisateur.getPrenom());
			pstmt.setString(++i, utilisateur.getRole());
			pstmt.setInt(++i, utilisateur.getIdEquipe());
			pstmt.setDate(++i,  utilisateur.getDateNaissance());
			
			// Log info
			logSQL(pstmt);
						
			// Execute la requête
			pstmt.executeUpdate();
		
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("SQL Error !:" + pstmt.toString(), e);
			throw e;
			
		} finally {
			pstmt.close();
		}
		
		return result;
	}

	/**
	 * Cette méthode permet de mettre à jour les informations d'un utilisateur.
	 * Elle prend en paramètre l'objet utilisateur que l'on souhaite mettre à jour
	 */
	@Override
	public Utilisateur updateUtilisateur(Utilisateur utilisateur) throws Exception {
		Utilisateur result = null;
		PreparedStatement pstmt = null;
		String sql = null;
		int i = 0;

		try {
			//Prépare la requête
			sql ="UPDATE utilisateur SET nom = ?, prenom = ?, role = ?, equipe_id = ?, date_naissance = ? WHERE id_utilisateur = ?";
			
			pstmt = dataSource.getConnection().prepareStatement(sql);
			pstmt.setString(++i, utilisateur.getNom());
			pstmt.setString(++i, utilisateur.getPrenom());
			pstmt.setString(++i, utilisateur.getRole());
			pstmt.setInt(++i, utilisateur.getIdEquipe());
			pstmt.setDate(++i, utilisateur.getDateNaissance());
			pstmt.setInt(++i, utilisateur.getId());
            
         // Log info
            logSQL(pstmt);
         			
         // Exécute la requête
         	int resultCount = pstmt.executeUpdate();
         	
         // Si la requête n'a aucun résultat
         	if(resultCount != 1)
         				throw new Exception("Utilisateur non trouvée !");
         			
         	result = utilisateur;

         		} catch (SQLException e) {
         			e.printStackTrace();
         			log.error("SQL Error !:" + pstmt.toString(), e);
         			throw e;
         			
         		} finally {
         			pstmt.close();
         		}

         		return result;
	}

	
	/**
	 * Cette fonction permet de vérifier lors de la création d'un utilisateur
	 * que l'utilisateur n'est pas déjà présent en base.
	 * Elle prend en paramètre l'utilisateur que l'on souhaite créer et renvoie
	 * true si l'utilisateur est déjà présent en base.
	 */
	@Override
	public boolean verifUtilisateurExiste(Utilisateur utilisateur) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs;
		int i = 0;
		boolean resultUtilisateur = false;
		String sql = null;
		
		try {
			//Prépare la requête
			sql = "SELECT * FROM utilisateur WHERE nom = ? AND prenom = ? AND date_naissance = ?";
			pstmt = dataSource.getConnection().prepareStatement(sql);
            
            pstmt.setString(++i, utilisateur.getNom());
            pstmt.setString(++i, utilisateur.getPrenom());
            pstmt.setDate(++i, utilisateur.getDateNaissance());
            
         // Log info
         	logSQL(pstmt);

         // Run requete
         	rs = pstmt.executeQuery();
         			
         // Si il y a un résultat on renvoie true
         	if (rs.next())
         		resultUtilisateur= true;
         	
         	} catch (SQLException e) {
         			e.printStackTrace();
         			log.error("SQL Error !:" + pstmt.toString(), e);
         			throw e;
         	
         	} finally {
         			pstmt.close();
         		}
		
         	return resultUtilisateur;
	}
	
	/**
	 * Cette fonction permet d'associer les valeurs de la base de données à leur attribut
	 * respectif de l'objet utilisateur
	 * @param rs
	 * @return utilisateur
	 * @throws SQLException
	 */
	private Utilisateur getUtilisateurFromResultSet(ResultSet rs) throws SQLException {
		Utilisateur utilisateur = new Utilisateur();
		utilisateur.setId(rs.getInt("id_utilisateur"));
		utilisateur.setNom(rs.getString("nom"));
		utilisateur.setPrenom(rs.getString("prenom"));
		utilisateur.setRole(rs.getString("role"));
		utilisateur.setIdEquipe(rs.getInt("equipe_id"));
		utilisateur.setDateNaissance(rs.getDate("date_naissance"));
		
		return utilisateur;		
	}
	
	private void logSQL(PreparedStatement pstmt) {
		String sql;
		
		if (pstmt == null)
			return;
		
		sql = pstmt.toString().substring(pstmt.toString().indexOf(":") + 2);
		log.debug(sql);
	}
}
