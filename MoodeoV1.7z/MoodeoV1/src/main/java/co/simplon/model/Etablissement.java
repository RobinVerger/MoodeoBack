package co.simplon.model;

/**
 * 
 * @author Robin
 * Cette classe regroupe les attributs spécifiques d'un établissement ainsi que les getter et 
 * Setter de ces attributs
 *
 */
public class Etablissement {

	private int id;
	private String nom;
	private String adresse;
	private String codePostal;
	private String region;
	
	public Etablissement(int id, String nom, String adresse, String codePostal, String region) {
		super();
		this.id = id;
		this.nom = nom;
		this.adresse = adresse;
		this.codePostal = codePostal;
		this.region = region;
	}
	
	public Etablissement() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	public String getCodePostal() {
		return codePostal;
	}

	public void setCodePostal(String codePostal) {
		this.codePostal = codePostal;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}
	
}
