package co.simplon.model;

import java.sql.Date;

/**
 * 
 * @author Robin
 * Cette classe regroupe les attributs spécifiques de l'humeur ainsi que les getter et 
 * setter de ces attributs  
 *
 */
public class Humeur {

	private float valeur;
	private Date dateCreation;
	private int idUtilisateur;
	
	public Humeur(int valeur, Date dateCreation, int idUtilisateur) {
		super();
		this.valeur = valeur;
		this.dateCreation = dateCreation;
		this.idUtilisateur = idUtilisateur;
	}

	public Humeur() {
		super();
	}


	public float getValeur() {
		return valeur;
	}

	public void setValeur(float valeur) {
		this.valeur = valeur;
	}

	public Date getDateCreation() {
		return dateCreation;
	}

	public void setDateCreation(Date dateCreation) {
		this.dateCreation = dateCreation;
	}

	public int getIdUtilisateur() {
		return idUtilisateur;
	}

	public void setIdUtilisateur(int idUtilisateur) {
		this.idUtilisateur = idUtilisateur;
	}
	
	
	
}
