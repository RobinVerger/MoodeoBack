package co.simplon.model;

import java.sql.Date;

/*
 * Cette classe regroupe les attributs d'un utilisateur de l'application ainsi que les getter
 * et setter de ces attributs
 */
public class Utilisateur {

	private int id;
	private String nom;
	private String prenom;
	private String role;
	private int idEquipe;
	private Date dateNaissance;
	
	public Utilisateur(int id, String nom, String prenom, String role, int idEquipe, Date dateNaissance) {
		super();
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.role = role;
		this.idEquipe = idEquipe;
		this.dateNaissance = dateNaissance;
	}

	public Utilisateur() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getIdEquipe() {
		return idEquipe;
	}

	public void setIdEquipe(int idEquipe) {
		this.idEquipe = idEquipe;
	}

	public Date getDateNaissance() {
		return dateNaissance;
	}

	public void setDateNaissance(Date dateNaissance) {
		this.dateNaissance = dateNaissance;
	}
	
	
	
}
