package co.simplon.model;

/*
 * Cette classe regroupe les attributs caractéristiques d'une équipe ainsi que les getter 
 * et setter de ces attibuts
 */
public class Equipe {

	private int id;
	private int idEtablissement;
	private String libEquipe;
	
	public Equipe(int id, int idEtablissement, String libEquipe) {
		super();
		this.id = id;
		this.idEtablissement = idEtablissement;
		this.libEquipe = libEquipe;
	}

	public Equipe() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIdEtablissement() {
		return idEtablissement;
	}

	public void setIdEtablissement(int idEtablissement) {
		this.idEtablissement = idEtablissement;
	}

	public String getLibEquipe() {
		return libEquipe;
	}

	public void setLibEquipe(String libEquipe) {
		this.libEquipe = libEquipe;
	}
	
	
}
