package co.simplon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.simplon.dao.EtablissementDAO;
import co.simplon.model.Etablissement;

/**
 * 
 * @author Robin
 * Cette classe permet de faire le lien entre EtablissementController et la DAO EtablissementDAO
 */
@Service
public class EtablissementService {

	@Autowired
	private EtablissementDAO dao;
	
	public List<Etablissement> getListeEtablissements() throws Exception {
		System.out.println("passage dans service");
		return dao.getListeEtablissements();
	}
	
	public Etablissement getEtablissement(int id) throws Exception {
		return dao.getEtablissement(id);
	}
	
	public Etablissement insertEtablissement(Etablissement etablissement) throws Exception {
		return dao.insertEtablissement(etablissement);
	}
	
	public Etablissement updateEtablissement(int id, Etablissement etablissement) throws Exception {
		return dao.updateEtablissement(etablissement);
	}
	
	public Etablissement getEtablissementUtilisateur(int idUtilisateur) throws Exception {
		return dao.getEtablissementUtilisateur(idUtilisateur);
	}
	
	public boolean verifEtablissementExiste(Etablissement etablissement) throws Exception {
		return dao.verifEtablissementExiste(etablissement);
	}
}
