package co.simplon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.simplon.dao.UtilisateurDAO;
import co.simplon.model.Utilisateur;

/**
 * 
 * @author Robin
 * Cette classe permet de faire le lien entre UtilisateurController et la DAO UtilisateurDAO
 */

@Service
public class UtilisateurService {


	@Autowired
	private UtilisateurDAO dao;
	
	public List<Utilisateur> getListeUtilisateurs() throws Exception {
		return dao.getListeUtilisateurs();
	}
	
	public List<Utilisateur> getListeUtilisateurParEtablissement(int idEtablissement) throws Exception {
		return dao.getUtilisateurParEtablissement(idEtablissement);
	}
	
	public Utilisateur getUtilisateur(int id) throws Exception {
		return dao.getUtilisateur(id);
	}
	
	public Utilisateur insertUtilisateur(Utilisateur utilisateur) throws Exception {
		return dao.insertUtilisateur(utilisateur);
	}
	
	public Utilisateur updateUtilisateur(int id, Utilisateur utilisateur) throws Exception {
		return dao.updateUtilisateur(utilisateur);
	}
	
	public boolean verifUtilisateurExiste(Utilisateur utilisateur) throws Exception {
		return dao.verifUtilisateurExiste(utilisateur);
	}
}
