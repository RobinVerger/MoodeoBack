package co.simplon.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.simplon.dao.HumeurDAO;
import co.simplon.model.Humeur;

/**
 * 
 * @author Robin
 * Cette classe permet de faire le lien entre HumeurController et la DAO HumeurDAO
 */
@Service
public class HumeurService {

	@Autowired
	private HumeurDAO dao;
	
	public Humeur getHumeur(int idUtilisateur) throws Exception {
		return dao.getHumeur(idUtilisateur);
	}
	
	public Humeur insertHumeur(Humeur humeur) throws Exception {
		return dao.insertHumeur(humeur);
	}
	
	public Humeur getHumeurEquipe(int idEquipe) throws Exception {
		return dao.getHumeurEquipe(idEquipe);
	}
	
	public Humeur getHumeurEtablissement(int idEtablissement) throws Exception {
		return dao.getHumeurEtablissement(idEtablissement);
	}
	
	public Humeur getHumeurEquipeMois(int idEquipe, int mois) throws Exception {
		return dao.getHumeurEquipeMois(idEquipe, mois);
	}
	
	public Humeur getHumeurEtablissementMois(int idEtablissement, int mois) throws Exception {
		return dao.getHumeurEtablissementMois(idEtablissement, mois);
	}
	
	public boolean verifVoteUtilisateur(Humeur humeur) throws Exception {
		return dao.verifVoteUtilisateur(humeur);
	}
	
	public Humeur getHumeurEquipeUtilisateur(int idUtilisateur) throws Exception {
		return dao.getHumeurEquipeUtilisateur(idUtilisateur);
	}
	
	public Humeur getHumeurEtablissementUtilisateur(int idUtilisateur) throws Exception {
		return dao.getHumeurEtablissementUtilisateur(idUtilisateur);
	}
	
	public Humeur getHumeurEquipeParDate(int idEquipe, String date) throws Exception {
		return dao.getHumeurEquipeParDate(idEquipe, date);
	}
	
	public Humeur getHumeurEtablissementParDate(int idEtablissement, String date) throws Exception {
		return dao.getHumeurEtablissementParDate(idEtablissement, date);
	}
}
