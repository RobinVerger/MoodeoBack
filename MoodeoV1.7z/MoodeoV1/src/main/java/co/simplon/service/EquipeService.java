package co.simplon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.simplon.dao.EquipeDAO;
import co.simplon.model.Equipe;

/**
 * 
 * @author Robin
 * Cette classe permet de faire le lien entre EquipeController et la DAO EquipeDAO
 */

@Service
public class EquipeService {


	@Autowired
	private EquipeDAO dao;
	
	public List<Equipe> getListeEquipes() throws Exception {
		return dao.getListeEquipes();
	}
	
	public List<Equipe> getListeEquipeEtablissement(int idEtablissement) throws Exception {
		return dao.getListeEquipeEtablissement(idEtablissement);
	}
	
	public Equipe getEquipe(int id) throws Exception {
		return dao.getEquipe(id);
	}
	
	public Equipe insertEquipe(Equipe equipe) throws Exception {
		return dao.insertEquipe(equipe);
	}
	
	public Equipe updateEquipe(int id, Equipe equipe) throws Exception {
		return dao.updateEquipe(equipe);
	}
	
	public boolean verifEquipeExiste(Equipe equipe) throws Exception {
		return dao.verifEquipeExiste(equipe);
	}
}
