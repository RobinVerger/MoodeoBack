package co.simplon.Csiback;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;

import co.simplon.dao.UtilisateurDAO;
import co.simplon.model.Utilisateur;
import co.simplon.service.UtilisateurService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CsibackApplicationTests {

	static Utilisateur utilisateur;
	static Utilisateur newUtilisateur;
	static UtilisateurService utilisateurService; 
	
	@Autowired
	UtilisateurDAO utilisateurDAO;
	
	@BeforeClass
	public static void initUtilisateur() throws Exception {
		utilisateurService = new UtilisateurService();
		utilisateur = new Utilisateur();
	}
	
	
	@Rollback(true)
    @Test
	public void testUpdateUtilisateur() {
		
	newUtilisateur = null;
	utilisateur = createMock("Verger", "Robin", "Administrateur", 1);
	
	try {
		newUtilisateur = utilisateurDAO.updateUtilisateur(utilisateur);
	} catch (Exception e) {
		e.printStackTrace();
	}
	assertTrue(newUtilisateur != null);
	assertEquals("Verger", newUtilisateur.getNom());
	}
	
	
	private Utilisateur createMock(String nom, String prenom, String role, int idEquipe) {
		Utilisateur mock = new Utilisateur();
		
		mock.setNom(nom);
		mock.setPrenom(prenom);
		mock.setRole(role);
		mock.setIdEquipe(idEquipe);
		mock.setId(new Integer(1));
		
		return mock;
	}
}
